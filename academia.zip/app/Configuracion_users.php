<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Configuracion_users extends Model
{
    //
}
