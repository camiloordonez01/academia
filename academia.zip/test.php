
<?php
phpinfo();
?>