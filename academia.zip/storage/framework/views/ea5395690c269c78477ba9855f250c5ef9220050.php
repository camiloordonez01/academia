
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5">
    <div class="row">
    	<div class="col-md-6 mx-auto">
    		<div class="card">
    			<div class="card-body">
    				<form method="POST" action="<?php echo e(url('/control/impugnar')); ?>">
                		<?php echo e(csrf_field()); ?>

	    				<h2 class="text-center">Impugnar Pregunta</h2>
	    				<ul style="border: 1px solid black; border-radius: 5px;list-style:none; padding: 0;">
	    					<li style="border-bottom: 1px solid black;text-align: center; padding: 10px 20px;">
	    						<h5>Pregunta:</h5>
	    						<p><?php echo e($pregunta->pregunta); ?></p>
	    						<input type="hidden" name="pregunta" value="<?php echo e($pregunta->pregunta); ?>">
	    					</li>
	    					<li style="border-bottom: 1px solid black;text-align: center;padding: 10px 20px;">
	    						<h5>Respuesta A:</h5>
	    						<p><?php echo e($respuestas[0]->respuesta); ?></p>
	    						<input type="hidden" name="respuesta[]" value="<?php echo e($respuestas[0]->respuesta); ?>">
	    					</li>
	    					<li style="border-bottom: 1px solid black;text-align: center;padding: 10px 20px;">
	    						<h5>Respuesta B:</h5>
	    						<p><?php echo e($respuestas[1]->respuesta); ?></p>
	    						<input type="hidden" name="respuesta[]" value="<?php echo e($respuestas[1]->respuesta); ?>">
	    					</li>
	    					<li style="border-bottom: 1px solid black;text-align: center;padding: 10px 20px;">
	    						<h5>Respuesta C:</h5>
	    						<p><?php echo e($respuestas[2]->respuesta); ?></p>
	    						<input type="hidden" name="respuesta[]" value="<?php echo e($respuestas[2]->respuesta); ?>">
	    					</li>
	    					<li style="border-bottom: 1px solid black;text-align: center;padding: 10px 20px;">
	    						<h5>Respuesta D:</h5>
	    						<p><?php echo e($respuestas[3]->respuesta); ?></p>
	    						<input type="hidden" name="respuesta[]" value="<?php echo e($respuestas[3]->respuesta); ?>">
	    					</li>
	    					<li style="padding: 10px 20px; text-align: center;">
	    						<h5>La respuesta correcta es
	    							<?php if($correcta->respuestas_id==$respuestas[0]->id): ?>
	    							A
	    							<input type="hidden" name="correcta" value="A">
	    							<?php elseif($correcta->respuestas_id==$respuestas[1]->id): ?>
	    							B
	    							<input type="hidden" name="correcta" value="B">
	    							<?php elseif($correcta->respuestas_id==$respuestas[2]->id): ?>
	    							C
	    							<input type="hidden" name="correcta" value="C">
	    							<?php elseif($correcta->respuestas_id==$respuestas[3]->id): ?>
	    							D
	    							<input type="hidden" name="correcta" value="D">
	    							<?php endif; ?>
	    						</h5>

	    					</li>
	    				</ul>
	    				<h5>Justificacion:</h5>
	    				<textarea style="height: 200px;margin-bottom: 20px;" class="form-control" placeholder="Escribe" name="justificacion"></textarea>
	    				<button class="btn boton-principal form-control">Enviar</button>
    				</form>
    			</div>
    		</div>
    	</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\academia\resources\views/panel/impugnacion/index.blade.php ENDPATH**/ ?>