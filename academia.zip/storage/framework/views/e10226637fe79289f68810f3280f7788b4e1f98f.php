
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 mx-auto" style="padding: 120px 0px">
            <div class="card">
                <div class="card-header">
                    <h4>Editar un documento</h4>
                </div>
                <div class="card-body">
                    <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($mensaje); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <?php echo Form::model($documento,['method'=>'PATCH','route'=>['documentos.update',$documento->id],'enctype'=>'multipart/form-data']); ?>

                    <?php echo e(Form::token()); ?>   
                        <div class="form-group">
                            <label for="nombre">Nombre del documento:</label>
                            <input type="text" name="nombre" class="form-control" value="<?php echo e($documento->nombre); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="tipo">Seleccionar tipo:</label>
                            <select name="tipo" class="form-control" required>
                                <option selected disabled>Seleccionar</option>
                                <option value="1" 
                                    <?php if($documento->tipo==1): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Resúmenes</option>
                                <option value="2" 
                                    <?php if($documento->tipo==2): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Audios</option>
                                <option value="3" 
                                    <?php if($documento->tipo==3): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Psicotécnicos</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="categoria">Seleccionar categoria:</label>
                            <select name="categoria" class="form-control" required>
                                <option selected disabled>Seleccionar</option>
                                <option value="1" 
                                    <?php if($documento->categoria==1): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Comunicaciones</option>
                                <option value="2" 
                                    <?php if($documento->categoria==2): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Constitución</option>
                                <option value="3" 
                                    <?php if($documento->categoria==3): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Decreto Legislativo 1/2006</option>
                                <option value="4" 
                                    <?php if($documento->categoria==4): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Espacios Naturales Protegidos</option>
                                <option value="5" 
                                    <?php if($documento->categoria==5): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Estatuto Básico del Empleado Público</option>
                                <option value="6" 
                                    <?php if($documento->categoria==6): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Exámenes Oficiales</option>
                                <option value="7" 
                                    <?php if($documento->categoria==7): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >INFOMA</option>
                                <option value="8" 
                                    <?php if($documento->categoria==8): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Igualdad</option>
                                <option value="9" 
                                    <?php if($documento->categoria==9): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Incendios forestales</option>
                                <option value="10" 
                                    <?php if($documento->categoria==10): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Ley de Prevención de Riesgos Laborales</option>
                                <option value="11" 
                                    <?php if($documento->categoria==11): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Los Servicios de Bomberos</option>
                                <option value="12" 
                                    <?php if($documento->categoria==12): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Orografía</option>
                                <option value="13" 
                                    <?php if($documento->categoria==13): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Simulacros oposición 2018-2019 (100 plazas)</option>
                                <option value="14" 
                                    <?php if($documento->categoria==14): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Simulacros oposición 2019-2020 (150 plazas)</option>
                                <option value="15" 
                                    <?php if($documento->categoria==15): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Teoría del fuego</option>
                                <option value="16" 
                                    <?php if($documento->categoria==16): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Carreteras</option>
                                <option value="17" 
                                    <?php if($documento->categoria==17): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Hidrografía</option>
                                <option value="18" 
                                    <?php if($documento->categoria==18): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Hojas de respuesta</option>
                                <option value="19" 
                                    <?php if($documento->categoria==19): ?>
                                    <?php echo e('selected'); ?>

                                    <?php endif; ?>
                                    >Psicotécnicos</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="documento">Seleccionar documento:</label>
                            <input type="file" name="documento" class="w-100">
                            <input type="hidden" name="urlDocumento" value="<?php echo e($documento->urlDocumento); ?>">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary boton-principal form-control">Editar</button>
                        </div>
                   <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\academia\resources\views/administrador/documentos/edit.blade.php ENDPATH**/ ?>