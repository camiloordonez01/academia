
<?php $__env->startSection('content'); ?>
<div class="container p-5">
    <div class="row">
        <div class="col-md-10 col-xl-10 mx-auto pb-2 text-right">
            <a href="documentos/create" class="btn btn-primary boton-principal">Crear</a>
        </div>
        <div class="col-md-10 col-xl-10 mx-auto ">
            <div class="card">
                <div class="card-body">
                    <table class="table" id="tablaContacto">
                        <thead>
                            <tr>
                                <td>Nombre</td>
                                <td>Tipo</td>
                                <td>Categoria</td>
                                <td>Documento</td>
                                <td>Acciones</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($documento->nombre); ?></td>
                                <td>
                                    <?php if($documento->tipo=='1'): ?>
                                    Resúmenes
                                    <?php elseif($documento->tipo=='2'): ?>
                                    Audios
                                    <?php elseif($documento->tipo=='3'): ?>
                                    Psicotécnicos
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($documento->categoria=='1'): ?>
                                    Comunicaciones
                                    <?php elseif($documento->categoria=='2'): ?>
                                    Constitución
                                    <?php elseif($documento->categoria=='3'): ?>
                                    Decreto Legislativo 1/2006
                                    <?php elseif($documento->categoria=='4'): ?>
                                    Espacios Naturales Protegidos
                                    <?php elseif($documento->categoria=='5'): ?>
                                    Estatuto Básico del Empleado Público
                                    <?php elseif($documento->categoria=='6'): ?>
                                    Exámenes Oficiales
                                    <?php elseif($documento->categoria=='7'): ?>
                                    INFOMA
                                    <?php elseif($documento->categoria=='8'): ?>
                                    Igualdad
                                    <?php elseif($documento->categoria=='9'): ?>
                                    Incendios forestales
                                    <?php elseif($documento->categoria=='10'): ?>
                                    Ley de Prevención de Riesgos Laborales
                                    <?php elseif($documento->categoria=='11'): ?>
                                    Los Servicios de Bomberos
                                    <?php elseif($documento->categoria=='12'): ?>
                                    Orografía
                                    <?php elseif($documento->categoria=='13'): ?>
                                    Simulacros oposición 2018-2019 (100 plazas)
                                    <?php elseif($documento->categoria=='14'): ?>
                                    Simulacros oposición 2019-2020 (150 plazas)
                                    <?php elseif($documento->categoria=='15'): ?>
                                    Teoría del fuego
                                    <?php elseif($documento->categoria=='16'): ?>
                                    Carreteras
                                    <?php elseif($documento->categoria=='17'): ?>
                                    Hidrografía
                                    <?php elseif($documento->categoria=='18'): ?>
                                    Hojas de respuesta
                                    <?php elseif($documento->categoria=='19'): ?>
                                    Psicotécnicos
                                    <?php endif; ?>
                                </td>
                                <td><a href="<?php echo e(Storage::url($documento->urlDocumento)); ?>">Ver</a></td>
                                <td>
                                    <a href="<?php echo e(URL::action('DocumentosController@edit',$documento->id)); ?>" class="btn btn-primary">Editar</a>
                                    <button data-toggle="modal" data-target="#modal-delete-<?php echo e($documento->id); ?>" class="btn btn-danger">Eliminar</button>
                                </td>
                                <?php echo $__env->make('administrador.documentos.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h1>No existen documentos</h1>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\academia\resources\views/administrador/documentos/index.blade.php ENDPATH**/ ?>