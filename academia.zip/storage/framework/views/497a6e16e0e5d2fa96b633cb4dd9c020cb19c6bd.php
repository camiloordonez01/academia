
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12 text-center">
            <h1 style="padding: 200px 0px;">Bienvenido <?php echo e($nombre); ?>,</br> Aca irían las estadisticas como la cantidad de usuarios!</h1>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\academia\resources\views/administrador/bienvenido.blade.php ENDPATH**/ ?>