<nav class="navbar navbar-expand-lg pr-4 pl-4 menu">
    <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('image/logo.png')); ?>" height="50" alt="">
    </a>
    <button class="navbar-toggler border border-white" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fas fa-bars text-white"></i>
    </button>
    <div class="collapse navbar-collapse justify-content-end pr-2" id="navbarNavDropdown">
        <?php if(Auth::user()): ?>
            <?php if(Auth::user()->tipo != 1): ?>
                <ul class="navbar-nav ">
                    <li class="nav-item pl-4">
                        <a class="nav-link <?php echo e((strpos(Request::path(), 'panel/estadisticas')!== false) ? 'active' : ''); ?>" href="estadisticas"><i class="fas fa-chart-bar icono-menu"></i>Tus Estadísticas</a>
                    </li>
                    <li class="nav-item pl-4">
                        <a class="nav-link <?php echo e((strpos(Request::path(), 'panel/test')!== false) ? 'active' : ''); ?>" href="test"><i class="fas fa-clipboard-check icono-menu"></i>Test</a>
                    </li>
                    <li class="nav-item pl-4">
                        <a class="nav-link <?php echo e((strpos(Request::path(), 'panel/documentos')!== false) ? 'active' : ''); ?>" href="documentos"><i class="fas fa-file-pdf icono-menu"></i>Documentos</a>
                    </li>
                    <li class="nav-item dropdown pl-4">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-cog icono-menu"></i>Más
                        </a>
                        <div class="dropdown-menu dropdown-menu-right mas" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item <?php echo e((strpos(Request::path(), 'panel/perfil')!== false) ? 'active' : ''); ?>" href="perfil"><i class="fas fa-user icono-menu"></i>Perfil</a>
                            <a class="dropdown-item" href="#"><i class="fas fa-user-plus icono-menu"></i>Mejorar plan</a>
                            <a class="dropdown-item" href="#"><i class="fas fa-comments icono-menu"></i>Preguntas comentadas</a>
                            <a class="dropdown-item" href="#"><i class="fas fa-question icono-menu"></i>Preguntas Guardadas</a>
                            <a class="dropdown-item" href="#"><i class="fas fa-question-circle icono-menu"></i>Dudas</a>
                            <hr style="height: 1px; width: 100%; background-color: #e9ecef;margin: .5rem 0;">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt icono-menu"></i>Salir</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </div>
                    </li>
                </ul>
            <?php else: ?>
                <ul class="navbar-nav ">
                    <li class="nav-item dropdown pl-4">
                        <a class="nav-link dropdown-toggle 
                            <?php echo e((strpos(Request::path(), 'administrador/test/temas')!== false) ? 'active' : ''); ?>

                            <?php echo e((strpos(Request::path(), 'administrador/test/preguntas')!== false) ? 'active' : ''); ?>

                        " href="#" id="testMenu" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-clipboard-check icono-menu"></i>Test
                        </a>
                        <div class="dropdown-menu mas" aria-labelledby="testMenu">
                            <a class="dropdown-item <?php echo e((strpos(Request::path(), 'administrador/test/temas')!== false) ? 'active' : ''); ?>" href="/administrador/test/temas"><i class="fas fa-ad icono-menu"></i>Temas</a>
                            <a class="dropdown-item <?php echo e((strpos(Request::path(), 'administrador/test/preguntas')!== false) ? 'active' : ''); ?>" href="/administrador/test/preguntas"><i class="fas fa-question-circle icono-menu"></i>Preguntas</a>
                        </div>
                    </li>
                    <li class="nav-item pl-4">
                        <a class="nav-link <?php echo e((strpos(Request::path(), 'administrador/documentos')!== false) ? 'active' : ''); ?>" href="/administrador/documentos"><i class="fas fa-file-pdf icono-menu"></i>Documentos</a>
                    </li>
                    <li class="nav-item pl-4">
                        <a class="nav-link <?php echo e((strpos(Request::path(), 'administrador/dudas')!== false) ? 'active' : ''); ?>" href="/administrador/dudas"><i class="fas fa-question-circle icono-menu"></i>Dudas</a>
                    </li>
                    <li class="nav-item pl-4">
                        <a class="nav-link <?php echo e((strpos(Request::path(), 'administrador/impugnadas')!== false) ? 'active' : ''); ?>" href="/administrador/impugnadas"><i class="fas fa-comments icono-menu"></i>Impugnadas</a>
                    </li>
                    <li class="nav-item dropdown pl-4">
                        <a class="nav-link dropdown-toggle
                            <?php echo e((strpos(Request::path(), 'administrador/perfil')!== false)? 'active' : ''); ?>

                        " href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-cog icono-menu"></i>Más
                        </a>
                        <div class="dropdown-menu dropdown-menu-right mas" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item <?php echo e((strpos(Request::path(), 'administrador/perfil')!== false)? 'active' : ''); ?>" href="/administrador/perfil"><i class="fas fa-user icono-menu"></i>Perfil</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt icono-menu"></i>Salir</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </div>
                    </li>
                </ul>
            <?php endif; ?>
        <?php else: ?>
            <ul class="navbar-nav "> 
                <li class="nav-item pl-4">
                    <a class="nav-link" href="#"><i class="fas fa-home icono-menu"></i>Inicio</a>
                </li>
            </ul>
        <?php endif; ?>
    </div>
  </nav><?php /**PATH C:\xampp2\htdocs\academia\resources\views/partials/menu.blade.php ENDPATH**/ ?>