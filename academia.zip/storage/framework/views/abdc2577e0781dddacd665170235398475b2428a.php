
<?php $__env->startSection('content'); ?>
<div class="container p-5">
    <div class="row">
        <div class="col-md-12 col-xl-12 mx-auto pb-2 text-right">
            <button class="btn btn-primary boton-principal" data-toggle="modal" data-target="#importar">Importar</button>
            <a href="preguntas/create" class="btn btn-primary boton-principal">Crear</a>
        </div>
        <div class="col-md-12 col-xl-12 mx-auto ">
            <div class="card">
                <div class="card-body">
                    <table class="table" id="tablaContacto">
                        <thead>
                            <tr>
                                <td width="200">Pregunta</td>
                                <td>Respuesta 1</td>
                                <td>Respuesta 2</td>
                                <td>Respuesta 3</td>
                                <td>Respuesta 4</td>
                                <td>Correcta</td>
                                <td>Acciones</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($dato['pregunta']->pregunta); ?></td>
                                <?php $__currentLoopData = $dato['respuestas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($respuesta->respuesta); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php for($i=0;$i < count($dato['respuestas']);$i++): ?>
                                    <?php if($dato['respuestas'][$i]->id==$dato['correcta']): ?>
                                    <td><?php echo e($i+1); ?></td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                <td>
                                    <a href="<?php echo e(URL::action('PreguntasController@edit',$dato['pregunta']->id)); ?>" class="btn btn-primary">Editar</a>
                                    <button data-toggle="modal" data-target="#modal-delete-<?php echo e($dato['pregunta']->id); ?>" class="btn btn-danger">Eliminar</button>
                                </td>
                                <?php echo $__env->make('administrador.test.preguntas.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h1>No existen temas</h1>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="importar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Cargar Datos</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/administrador/test/import')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <input type="file" name="select_file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"/>
                    <span class="text-muted">.xls, .xslx</span>
                    <input type="submit" name="upload" class="btn btn-primary form-control mt-3 boton-principal" value="Upload">
                </div>
            </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\academia\resources\views/administrador/test/preguntas/index.blade.php ENDPATH**/ ?>