
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5">
    <div class="row">
    	<div class="col-md-6">
    		<h1>Ranking de usuarios</h1>
    	</div>
    	<div class="col-md-6 text-right">
    		<h3>Mi identificacion es: <span style="color: #F7BE2C; font-weight: bold;"><?php echo e($idUser); ?></span></h3>
    	</div>
    	<div class="col-md-6 mt-4">
    		<table class="table">
    			<h2>Top 10 de hoy</h2>
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">Identificacion</th>
			      <th scope="col">Acertadas</th>
			      <th scope="col">Falladas</th>
			      <th scope="col">Puntos</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php $__currentLoopData = $datosdiarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <tr>
			      <th scope="row"><?php echo e($loop->iteration); ?></th>
			      <td><?php echo e($dato['users_id']); ?></td>
			      <td><?php echo e($dato['correctas']); ?></td>
			      <td><?php echo e($dato['incorrectas']); ?></td>
			      <td><?php echo e($dato['puntos']); ?></td>
			    </tr>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table>
    	</div>
    	<div class="col-md-6 mt-4">
    		<table class="table">
    			<h2>Top 10 de este mes</h2>
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">Identificacion</th>
			      <th scope="col">Acertadas</th>
			      <th scope="col">Falladas</th>
			      <th scope="col">Puntos</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php $__currentLoopData = $datosmensuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <tr>
			      <th scope="row"><?php echo e($loop->iteration); ?></th>
			      <td><?php echo e($dato['users_id']); ?></td>
			      <td><?php echo e($dato['correctas']); ?></td>
			      <td><?php echo e($dato['incorrectas']); ?></td>
			      <td><?php echo e($dato['puntos']); ?></td>
			    </tr>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table>
    	</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\academia\resources\views/panel/ranking/index.blade.php ENDPATH**/ ?>