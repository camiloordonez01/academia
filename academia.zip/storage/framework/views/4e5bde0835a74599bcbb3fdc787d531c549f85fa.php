
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 mt-3">
            <h1>Progreso alumno: <?php echo e($alumno); ?></h1>
        </div>
        <div class="col-md-6 mt-5">
            <h3>Preguntas Acertadas y falladas totales </h3>
            <canvas id="chart-area"></canvas>
        </div>
        <div class="col-md-6 mt-5">
            <h3>Preguntas respondidas de todos los temas</h3>
            <canvas id="chart-area2"></canvas>
            <input type="hidden" id="tortaNumeros" value="<?php echo e($tortaNombre); ?>">
            <script>
                var randomScalingFactor = function() {
                    return Math.round(Math.random() * 100);
                };
                var config = {
                    type: 'pie',
                    data: {
                        datasets: [{
                            data: [
                                <?php echo e($correctas); ?>,
                                <?php echo e($incorrectas); ?>

                            ],
                            backgroundColor: [
                                'rgb(90, 164, 84)',
                                'rgb(161, 10, 40)'
                            ],
                            label: 'Dataset 1'
                        }],
                        labels: [
                            'Acertadas',
                            'Falladas'
                        ]
                    },
                    options: {
                        responsive: true
                    }
                };
                var tortaNumeros = <?php echo e($tortaNumeros); ?>;
                var tortaNombre = JSON.parse($('#tortaNumeros').val());
                var config2 = {
                    type: 'pie',
                    data: {
                        datasets: [{
                            data: tortaNumeros,
                            backgroundColor: [
                                'rgb(168, 56, 93)',
                                'rgb(122, 163, 229)',
                                'rgb(162, 126, 168)',
                                'rgb(170, 227, 245)',
                                'rgb(173, 205, 237)',
                                'rgb(169, 89, 99)',
                                'rgb(135, 150, 192)',
                                'rgb(168, 56, 93)',
                                'rgb(122, 163, 229)',
                                'rgb(162, 126, 168)',
                                'rgb(170, 227, 245)',
                                'rgb(173, 205, 237)',
                                'rgb(169, 89, 99)',
                                'rgb(135, 150, 192)',
                                'rgb(168, 56, 93)',
                                'rgb(122, 163, 229)',
                                'rgb(162, 126, 168)',
                                'rgb(170, 227, 245)',
                                'rgb(173, 205, 237)',
                                'rgb(169, 89, 99)',
                                'rgb(135, 150, 192)',
                                'rgb(168, 56, 93)',
                                'rgb(122, 163, 229)',
                                'rgb(162, 126, 168)',
                                'rgb(170, 227, 245)',
                                'rgb(173, 205, 237)',
                                'rgb(169, 89, 99)'
                            ],
                            label: 'Dataset 1'
                        }],
                        labels: tortaNombre
                    },
                    options: {
                        responsive: true
                    }
                };
        
                window.onload = function() {
                    var ctx = document.getElementById('chart-area2').getContext('2d');
                    window.myPie = new Chart(ctx, config2);

                    var ctx = document.getElementById('chart-area').getContext('2d');
                    window.myPie = new Chart(ctx, config);
                };
            </script>
        </div>
        <div class="col-md-12 mt-5">
            <h3>Preguntas acertadas y falladas por tema</h3>
        </div>
        <?php $__currentLoopData = $totalCategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 ">
            <div style="width: 100%;">
                <h5>
                    <?php if($categoria[0]=='1'): ?>
                    Legislación
                    <?php elseif($categoria[0]=='2'): ?>
                    Temario específico
                    <?php elseif($categoria[0]=='3'): ?>
                    Resto de materias
                    <?php endif; ?>
                </h5>
                <?php $__currentLoopData = $categoria[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="width: 98%;margin-left:2%;float: left;" class="mt-2 mb-2">
                    <div style="width: 12%;float: left;">
                        <p style="white-space: nowrap;text-overflow: ellipsis;overflow: hidden;font-size: 12px;"><?php echo e($item[3]); ?></p>
                    </div>
                    <div style="height:26px; width: 80%; background-color:rgba(0,0,0,.05);padding: 4px 0px;float: left;">
                        <div style="height:6px;border-top-right-radius: 3px;border-bottom-right-radius: 3px;margin-bottom:6px;background-color:rgb(90, 164, 84);width: <?php echo e($item[0]); ?>%;" class="progress-bar" aria-valuemin="0" aria-valuemax="100" data-toggle="tooltip" data-placement="top" data-html="true" title="<?php echo e($item[3]); ?> • Acertadas </br> <?php echo e($item[4]); ?>"></div>
                        <div style="height:6px;border-top-right-radius: 3px;border-bottom-right-radius: 3px;background-color:rgb(161, 10, 40);width: <?php echo e($item[1]); ?>%;" class="progress-bar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" data-toggle="tooltip" data-placement="top" data-html="true" title="<?php echo e($item[3]); ?> • Falladas </br> <?php echo e($item[5]); ?>"></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12 mt-5 mb-5">
            <form method="POST" action="<?php echo e(url('/control/estadisticas')); ?>">
                <?php echo e(csrf_field()); ?>

                <button class="btn boton-principal" type="submit">Resetear Estadisticas</button>
            </form>
        </div>
    </div>
</div>

<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\academia\resources\views/panel/estadisticas.blade.php ENDPATH**/ ?>