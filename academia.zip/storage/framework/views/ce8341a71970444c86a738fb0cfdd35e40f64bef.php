
<?php $__env->startSection('head'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5">
    <div class="row">
    	<div class="col-md-12">
    		<h1>Pregunta comentadas:</h1>
    	</div>
    	<div class="col-md-12">
    		<ul>
    			<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<li>
    				<h5><?php echo e($pregunta[0]->pregunta); ?></h5>
    				<ul>
    					<?php $__currentLoopData = $pregunta[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuestas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    					<li 
     						<?php if($pregunta[2]->respuestas_id == $respuestas->id): ?>
     						class="text-success"
     						<?php endif; ?>
    					><?php echo e($respuestas->respuesta); ?></li>
    					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				</ul>
    				<h5 class="mt-5 pl-5" data-toggle="collapse" href="#collapseRes<?php echo e($pregunta[0]->id); ?>" role="button" aria-expanded="false" aria-controls="collapseRes<?php echo e($pregunta[0]->id); ?>" style="cursor: pointer;"><i class="fas fa-chevron-down pr-2"></i>Comentarios y Dudas sobre la pregunta (<?php echo e(count($pregunta[3])); ?>)</h5>
                        <div class="collapse pl-5" id="collapseRes<?php echo e($pregunta[0]->id); ?>" >
                            
                            
                            <?php $__currentLoopData = $pregunta[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-3">
                                <div class="card-header new-comment">
                                    <?php echo e($comentario->name); ?>

                                </div>
                                <div class="card-body">
                                    <?php echo e($comentario->comentario); ?>

                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-3" id="nuevoComentario<?php echo e($pregunta[0]->id); ?>" style="display: none;">
                            </div>
                            <h5>Comenta: </h5>
                            <div class="card">
                                <div class="card-header new-comment">
                                    <h5 class="mt-1">Nombre</h5>
                                </div>
                                <div class="card-body">
                                    <link href="<?php echo e(asset('css/quill.snow.css')); ?>" rel="stylesheet">
                                    

                                    <div id="editorRes<?php echo e($pregunta[0]->id); ?>" class="p-1" style="height: 200px;"></div>

                                    <button class="btn boton-principal mt-3 float-right" id="enviarPregunta<?php echo e($pregunta[0]->id); ?>">Enviar comentario</button>
                                    <script src="<?php echo e(asset('js/quill.min.js')); ?>"></script>
                                    <script>
                                        $(document).ready(function(){
                                            var quill = new Quill('#editorRes<?php echo e($pregunta[0]->id); ?>', {
                                                placeholder: 'Escribe aqui',
                                                theme: 'snow'
                                            });
                                            $('#enviarPregunta<?php echo e($pregunta[0]->id); ?>').click(function(){
                                                var comentario = $('#editorRes<?php echo e($pregunta[0]->id); ?> .ql-editor p' ).html();
                                                $.ajax({
                                                    url:'quiz/comentario',
                                                    data:{'comentario' : comentario, 'pregunta_id': <?php echo e($pregunta[0]->id); ?> },
                                                    type:'post',
                                                    success: function (response) {
                                                        $('#editorRes<?php echo e($pregunta[0]->id); ?> .ql-editor p' ).html('');
                                                        $('#nuevoComentario<?php echo e($pregunta[0]->id); ?>').html(
                                                            `<div class="card-header new-comment">
                                                                `+response+`
                                                            </div>
                                                            <div class="card-body">
                                                                `+comentario+`
                                                            </div>`
                                                            );
                                                        $('#nuevoComentario<?php echo e($pregunta[0]->id); ?>').css('display','block');
                                                        console.log('ok');
                                                    },
                                                    error:function(response){
                                                        console.log(response.responseText);
                                                    }
                                                });
                                            });
                                        });
                                    </script>
                                </div>
                            </div>
                        </div>
    			</li>
    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</ul>
    	</div>
    </div>
</div>
<script>
	$(document).ready(function(){
		$.ajaxSetup({
             headers: {
                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
             }
         });
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\academia\resources\views/panel/comentadas/index.blade.php ENDPATH**/ ?>