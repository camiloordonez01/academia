<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <h4 class="text-white mb-3" style="font-size: 25px;">Academia<span style="color: #F7BE2C;">Central</span></h4>
                <div class="text-white mb-1" style="font-size: 12px;">
                    <a href="#" class="text-white">Inicio</a> –
                    <a href="#" class="text-white">La Oposición</a> –
                    <a href="#" class="text-white">Tarifas</a> –
                    <a href="#" class="text-white">Login</a>
                </div>
                <p style="color: #7a7a7a;font-weight: 400;font-size: 11px;">academiacentral.com © 2018</p>
                <p class="mt-5" style="color: #7a7a7a;font-weight: 400;font-size: 11px;">Developed by justmarketing</p>
            </div>
            <div class="col-md-4">
                <p class="m-0" style="color: #F7BE2C;    font-size: 14px;">
                    <i aria-hidden="true" class="fab fa-whatsapp-square icono-menu"></i>
                    633333333
                </p>
                <p style="color: #F7BE2C;    font-size: 14px;">
                    <i aria-hidden="true" class="fas fa-envelope icono-menu pt-1"></i>
                    info@academiacentral.com
                </p>
                <p style="color: #F7BE2C;    font-size: 14px;padding-top:40px;">
                    Aviso legal<br>
                    Política de privacidad<br>
                    Política de Cookies
                </p>
            </div>
            <div class="col-md-4">
                <p style="color: white;    font-size: 12px;margin-bottom: 20px;">Acerca de academiacentral.com</p>
                <p style="color: #7a7a7a;    font-size: 12px;">academiacentral.com el portal que te ayudará de forma eficaz a aprobar tus oposiciones de bombero.</p>
                <p>
                    <i aria-hidden="true" class="fab fa-facebook-square" style="color: #33383B; font-size: 30px;"></i>
                    <i aria-hidden="true" class="fab fa-twitter-square" style="color: #33383B; font-size: 30px;"></i>
                    <i aria-hidden="true" class="fab fa-instagram" style="color: #33383B; font-size: 30px;"></i>
                </p>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\academia\resources\views/partials/footer.blade.php ENDPATH**/ ?>