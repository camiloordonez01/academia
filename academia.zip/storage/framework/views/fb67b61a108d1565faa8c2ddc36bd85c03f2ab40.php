
<?php $__env->startSection('content'); ?>
<div class="container p-5">
    <div class="row">
        <div class="col-md-10 col-xl-10 mx-auto pb-2 text-right">
            <a href="temas/create" class="btn btn-primary boton-principal">Crear</a>
        </div>
        <div class="col-md-10 col-xl-10 mx-auto ">
            <div class="card">
                <div class="card-body">
                    <table class="table" id="tablaContacto">
                        <thead>
                            <tr>
                                <td>Tema</td>
                                <td>Categoria</td>
                                <td>Acciones</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($tema->tema); ?></td>
                                <td>
                                    <?php if($tema->categoria=='1'): ?>
                                    Legislación
                                    <?php elseif($tema->categoria=='2'): ?>
                                    Temario específico
                                    <?php elseif($tema->categoria=='3'): ?>
                                    Resto de materias
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(URL::action('TemasController@edit',$tema->id)); ?>" class="btn btn-primary">Editar</a>
                                    <button data-toggle="modal" data-target="#modal-delete-<?php echo e($tema->id); ?>" class="btn btn-danger">Eliminar</button>
                                </td>
                                
                                <?php echo $__env->make('administrador.test.temas.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h1>No existen temas</h1>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\academia\resources\views/administrador/test/temas/index.blade.php ENDPATH**/ ?>