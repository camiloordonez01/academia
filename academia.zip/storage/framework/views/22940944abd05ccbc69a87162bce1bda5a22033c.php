<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academia Central</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/index.css">
    <link href="font/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/dataTables.css">
    <link rel="stylesheet" href="css/sweetalert2.min.css">
    <link rel="stylesheet" href="css/Chart.css">
    <script src="js/Chart.js"></script>
    <script src="js/sweetalert2.all.min.js"></script>
    <script src="js/jquery-3.4.1.min.js"></script>
</head>
<body>
    <?php echo $__env->make('partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/index.js"></script>
    <script src="js/dataTables.js"></script>
    <script src="font/js/all.js"></script>
</body>
</html><?php /**PATH C:\xampp2\htdocs\academia\academiacentral\resources\views/layouts/main.blade.php ENDPATH**/ ?>