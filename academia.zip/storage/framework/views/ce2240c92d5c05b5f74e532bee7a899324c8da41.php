
<?php $__env->startSection('content'); ?>
<div class="container p-5">
    <div class="row">
        <div class="col-md-12 col-xl-12 mx-auto pb-2 text-right">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    Error al cargar<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-12 col-xl-12">
            <h2 class="text-center">Datos Cargados</h2>
        </div>
        <div class="col-md-12 col-xl-12 mx-auto ">
            <div class="card">
                <div class="card-body">
                    <style>
                        table.dataTable thead .sorting:after,
                        table.dataTable thead .sorting:before,
                        table.dataTable thead .sorting_asc:after,
                        table.dataTable thead .sorting_asc:before,
                        table.dataTable thead .sorting_asc_disabled:after,
                        table.dataTable thead .sorting_asc_disabled:before,
                        table.dataTable thead .sorting_desc:after,
                        table.dataTable thead .sorting_desc:before,
                        table.dataTable thead .sorting_desc_disabled:after,
                        table.dataTable thead .sorting_desc_disabled:before {
                            bottom: .5em;
                        }
                    </style>
                    <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0"
                    width="100%">
                        <thead>
                            <tr>
                                <td width="200" class="th-sm">Pregunta</td>
                                <td class="th-sm">Respuesta 1</td>
                                <td class="th-sm">Respuesta 2</td>
                                <td class="th-sm">Respuesta 3</td>
                                <td class="th-sm">Respuesta 4</td>
                                <td class="th-sm">Correcta</td>
                                <td class="th-sm">Tema</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!$empty): ?>
                                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dato["pregunta"]); ?></td>
                                    <td><?php echo e($dato["respuesta1"]); ?></td>
                                    <td><?php echo e($dato["respuesta2"]); ?></td>
                                    <td><?php echo e($dato["respuesta3"]); ?></td>
                                    <td><?php echo e($dato["respuesta4"]); ?></td>
                                    <td><?php echo e($dato["correcta"]); ?></td>
                                    <td><?php echo e($dato["tema"]); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                            <h1>No existen datos</h1>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <script>
                        $(document).ready(function () {
                            $('#dtVerticalScrollExample').DataTable({
                                "scrollY": "300px",
                                "scrollCollapse": true,
                            });
                            $('.dataTables_length').addClass('bs-select');
                        });
                    </script>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-xl-12 mx-auto ">
            <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/administrador/test/preguntas/load')); ?>" class="text-right">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="datos" value="<?php echo e(json_encode($datos)); ?>">
                <button type="submit" class="btn boton-principal mt-4">Confirmar creacion</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\academia\resources\views/administrador/test/preguntas/import.blade.php ENDPATH**/ ?>