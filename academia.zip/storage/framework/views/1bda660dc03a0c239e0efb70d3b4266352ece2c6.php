    
    <?php $__env->startSection('head'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5">
    <div class="row">
        <div class="col-md-12">
            <label for="">
                <span id="contador">1</span>
                / <?php echo e($cantidad); ?>

            </label>
        </div>
        <div class="col-md-12">
            <!-- Slider main container -->
            <div class="swiper-container">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->
                    <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <h5 class="text-center"><?php echo e($pregunta[0]->pregunta); ?></h5>
                        <div class="answer">
                            <ul>
                                <?php $__currentLoopData = $pregunta[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuestas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="respuesta<?php echo e($respuestas->id); ?>" onclick="responder(<?php echo e($respuestas->id); ?>,<?php echo e($pregunta[2]->respuestas_id); ?>,<?php echo e($pregunta[0]->id); ?>,<?php echo e($pregunta[0]->temas_id); ?>)"><?php echo e($respuestas->respuesta); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <input type="hidden" id="respondida<?php echo e($pregunta[0]->id); ?>" value="false">
                        <h5 data-toggle="collapse" href="#collapseRes<?php echo e($pregunta[0]->id); ?>" role="button" aria-expanded="false" aria-controls="collapseRes<?php echo e($pregunta[0]->id); ?>" style="cursor: pointer;"><i class="fas fa-chevron-down pr-2"></i>Comentarios y Dudas sobre la pregunta (0)</h5>
                        <div class="collapse" id="collapseRes<?php echo e($pregunta[0]->id); ?>" >
                            <h5>Comenta: </h5>
                            <div class="card">
                                <div class="card-header new-comment">
                                    <h5 class="mt-1">Nombre</h5>
                                </div>
                                <div class="card-body">
                                    <link href="<?php echo e(asset('css/quill.snow.css')); ?>" rel="stylesheet">
    
                                    <div id="editorRes<?php echo e($pregunta[0]->id); ?>" class="p-1" style="height: 200px;"></div>

                                    <button class="btn boton-principal mt-3 float-right" id="enviarPregunta<?php echo e($pregunta[0]->id); ?>">Enviar comentario</button>
                                    <script src="<?php echo e(asset('js/quill.min.js')); ?>"></script>
                                    <script>
                                        $(document).ready(function(){
                                            var quill = new Quill('#editorRes<?php echo e($pregunta[0]->id); ?>', {
                                                placeholder: 'Escribe aqui',
                                                theme: 'snow'
                                            });
                                            $('#enviarPregunta<?php echo e($pregunta[0]->id); ?>').click(function(){
                                                console.log('entro');
                                            });
                                        });
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <h4 class="mb-3 text-center">Estos son tus resultados:</h4>
                        <h5 class="text-success text-center">Acertadas: <span id="acertadas">0</span></h5>
                        <h5 class="text-danger text-center">Falladas: <span id="falladas">0</span></h5>
                        <div class="row mt-4 justify-content-center">
                            <div class="col-12 col-sm-4">
                              <button class="btn boton-principal d-block mx-auto my-2">Nuevo test, mismos temas</button>
                            </div>
                            <div class="col-12 col-sm-4">
                              <button class="btn boton-principal d-block mx-auto my-2">Nuevo test</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- If we need pagination -->
                <div class="swiper-pagination" hidden=""></div>

                <!-- If we need navigation buttons -->
                <div class="swiper-button-prev swiper-button-disabled" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="true"></div>
                <div class="swiper-button-next" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false"></div>

            </div>
        </div>
    </div>
</div>
<script>
    var correctas = 0;
    var incorrectas = 0;

    $(document).ready(function () {
        //initialize swiper when document ready
        $.ajaxSetup({
             headers: {
                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
             }
         });
        var mySwiper = new Swiper ('.swiper-container', {
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            simulateTouch: false
        });
        $('.swiper-button-next').on('click', function(){
            var contador = $('#contador').html();
            $('#contador').html(parseInt(contador)+1);
        });
        $('.swiper-button-prev').on('click', function(){
            var contador = $('#contador').html();
            $('#contador').html(parseInt(contador)-1);
        });
    });
    function responder(respuesta, correcta, pregunta, tema){
        if($('#respondida'+pregunta).val()=='false'){
            if(respuesta==correcta){
                $('.respuesta'+respuesta).addClass('correcta');
                correctas = correctas + 1;
                $('#acertadas').html(correctas);

                $.ajax({
                    url:'quiz/save',
                    data:{'tema' : tema, 'correctas':1, 'incorrectas':0, 'pregunta':''},
                    type:'post',
                    success: function (response) {
                        console.log(response);
                    },
                    error:function(response){
                        console.log(response.responseText);
                    }
                });

            }else{
                $('.respuesta'+respuesta).addClass('incorrecta');
                $('.respuesta'+correcta).addClass('correcta');
                incorrectas = incorrectas + 1;
                $('#falladas').html(incorrectas);
                $.ajax({
                    url:'quiz/save',
                    data:{'tema' : tema, 'correctas':0, 'incorrectas':1, 'pregunta':pregunta},
                    type:'post',
                    success: function (response) {
                        console.log(response);
                    },
                    error:function(response){
                        console.log(response.responseText);
                    }
                });

            }
            $('#respondida'+pregunta).val('true');
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\academia\resources\views/panel/test/quiz.blade.php ENDPATH**/ ?>