<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <h4 class="text-white mb-3" style="font-size: 25px;">Academia<span style="color: #F7BE2C;">Central</span></h4>
                <div class="text-white mb-1" style="font-size: 12px;">
                    <a href="#" class="text-white">Inicio</a> –
                    <a href="#" class="text-white">La Oposición</a> –
                    <a href="#" class="text-white">Tarifas</a> –
                    <a href="#" class="text-white">Login</a>
                </div>
            </div>
            <div class="col-md-4">
                <p class="m-0" style="color: #F7BE2C;    font-size: 14px;">
                    <img class="icono-menu" src="{{asset('image/whatsapp.png')}}">
                    667754320
                </p>
                <p style="color: #F7BE2C;    font-size: 14px;">
                    <img class="icono-menu" src="{{asset('image/11.png')}}">
                    gestionacademia@academiacentralstation.com
                </p>
                <p style="color: #F7BE2C;    font-size: 14px;padding-top:40px;">
                    Aviso legal<br>
                    Política de privacidad<br>
                    Política de Cookies
                </p>
            </div>
            <div class="col-md-4">
                <p style="color: white;    font-size: 12px;margin-bottom: 20px;">Acerca de academiacentral.com</p>
                <p>
                    <img style="width: 30px;" src="{{asset('image/facebook.png')}}">
                    <img style="width: 30px;" src="{{asset('image/twitter.png')}}">
                    <img style="width: 30px;" src="{{asset('image/instagram.png')}}">
                </p>
            </div>
        </div>
    </div>
</div>