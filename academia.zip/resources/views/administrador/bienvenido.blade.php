@extends('layouts.main')
@section('content')
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12 text-center">
            <h1 style="padding: 200px 0px;">Bienvenido {{$nombre}},</br> Aca irían las estadisticas como la cantidad de usuarios!</h1>
        </div>
    </div>
</div>
@endsection